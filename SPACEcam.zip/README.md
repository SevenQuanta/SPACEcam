# SPACEcam

**S**pecialized **P**ersonal **A**utomatic **C**oordinate **E**valuator **cam**era


## Keeping up to date
`$pip install -r requirements.txt`
