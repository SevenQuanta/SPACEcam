X = test(2,2:end);
Y = test(3,2:end);
Z = test(4,2:end);

scatter3(X,Y,Z)
axis equal